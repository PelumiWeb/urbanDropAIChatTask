# Handoff: Drop AI — conversational shopping (UrbanDrop)

## Overview
Drop AI is UrbanDrop's in-app shopping assistant. It launches full-screen from the green
circular button inside the home search bar and lets a shopper ask for recipes, deals,
reorders or products in natural language. Answers come back as a chat transcript where
assistant turns can carry **rich payloads** — a suggested basket, a swipeable rail of store
cards with product tiles, or past orders with a one-tap Reorder CTA.

Scope of this handoff: the **entire Drop AI surface** — greeting/empty state, typeahead,
thinking, four answer payload types, chat history, voice capture, error state, overflow menu,
composer and basket toast. **No backend.** Everything renders from a mock fixture module.

## About the design files
The files in `prototype/` are **design references written in HTML** — a working prototype that
shows intended look and behaviour. They are *not* production code to lift. The task is to
**recreate this design in your codebase's existing environment** (React Native, React, Vue,
SwiftUI, whatever you're on) using its established components, navigation and styling
patterns. If no environment exists yet, choose the framework that suits the app and build it
there.

`prototype/drop-ai-mock.js` is the one exception: it is a plain ES module of fixtures and is
meant to be **copied into your project as-is** and used until the backend lands.

## Fidelity
**High fidelity.** Colours, type, spacing, radii, shadows, motion durations and copy are all
final and taken from the UrbanDrop design system (`prototype/_ds/urbandrop/colors_and_type.css`,
generated from `UrbanDrop.fig`). Recreate pixel-for-pixel. Photography is intentionally
placeholder (diagonal hatch blocks labelled `SHOP PHOTO` / product tiles) — swap in real
merchant and product imagery.

Device target: **390 × 838** viewport (iPhone 14/15 class), rendered inside a 42px-radius frame
in the prototype. The phone frame is prototype chrome only — don't build it.

## Screenshots

Captured from the prototype at 390 × 838. Each file is the exact state described in the
matching section below.

| | | |
|---|---|---|
| ![Empty / greeting](screenshots/01-empty-greeting.png)<br>**01** Empty / greeting — §1 | ![Typeahead](screenshots/02-typeahead.png)<br>**02** Typeahead sheet — §2 | ![Thinking](screenshots/03-thinking.png)<br>**03** Thinking — §3 |
| ![Answer + basket](screenshots/04-answer-basket.png)<br>**04** Answer + suggested basket — §4 | ![Store results](screenshots/05-store-results.png)<br>**05** Store results — §5 | ![Deals](screenshots/06-deals.png)<br>**06** Deals — §6 |
| ![Reorder](screenshots/07-reorder.png)<br>**07** Reorder — §7 | ![Chat history](screenshots/08-chat-history.png)<br>**08** Chat history — §8 | ![Voice capture](screenshots/09-voice-capture.png)<br>**09** Voice capture — §9 |
| ![Error](screenshots/10-error.png)<br>**10** Error + retry — §10 | ![Toast](screenshots/11-toast-add-to-basket.png)<br>**11** Add-to-basket toast — §12 | ![Overflow menu](screenshots/12-overflow-menu.png)<br>**12** Overflow menu — §11 |

Screenshots show one scroll position each — open the prototype to see the full transcript,
carousel scrolling and motion.

---

## Screens / views

All views live in **one** screen (`DropAIScreen`). There is no navigation between them — the
transcript and overlays change. Panel background is `#F3EFE9` throughout.

### Persistent chrome

**Status bar** — prototype only, replace with the platform status bar. `padding: 14px 26px 0`.

**Header** (`flex: 0 0 auto`, `padding: 14px 20px 10px`, space-between)
- Back `‹` — 34×34 hit box, 26px glyph, `#16241D`. Press: `scale(.85)`. Closes Drop AI (or
  resets to the greeting if a conversation is open — see Interactions).
- Centre cluster, gap 8px: 24×24 circle `#183A37` containing `assets/logo-mark.png` at 19×19;
  title `Drop AI` — Red Hat Display 800 / 16px / `#16241D`; `BETA` pill — 700 / 10px /
  `letter-spacing .08em` / uppercase, colour `#5CB35E`, bg `rgba(92,179,94,.14)`, radius 6px,
  padding `3px 7px`.
- Overflow `⋮` — 34×34, 20px glyph, `#16241D`. Opens the menu.

**Transcript scroller** — `flex: 1`, `overflow-y: auto`, `padding: 8px 20px 10px`, scrollbar
hidden. Above every transcript: `Chat started · 08:47` centred, 600 / 12px / `#8B968F`,
`margin-bottom: 16px`; then the greeting, 500 / 21px / line-height 1.35 / `#16241D`,
`margin-bottom: 18px`. Greeting copy: `Hungry, {firstName}? Let’s sort it.`

**Composer** (`flex: 0 0 auto`, `padding: 14px 20px 22px`, bg `rgba(255,255,255,.35)`,
`border-top: 1px solid rgba(255,255,255,.6)`)
- Input row: bg `#FFF`, radius 28px, `padding: 7px 7px 7px 18px`, shadow
  `0 4px 12px -6px rgba(8,7,7,.2)`, `margin-bottom: 13px`.
  - Text input — Red Hat Display 400 / 16px / `#16241D`, placeholder `Ask anything…` in
    `#8B968F` (native placeholder colour), no border, `padding: 9px 0`.
  - Send `↑` — 42×42 circle, glyph 20px `#FFF`. Bg `#CFC9BF` when the draft is empty,
    accent `#5CB35E` when non-empty. Press: `scale(.9)`.
- Action row (space-between):
  - `🎙 Voice chat` pill — bg `#FFF`, radius 30px, `padding: 12px 20px`, label 800 / 15px /
    `#16241D`, gap 10px, same shadow. Press `scale(.97)`.
  - Basket FAB — 52×52 circle, bg accent `#5CB35E`, 🧺 glyph 22px, with a badge at
    `top:-4px right:-4px`: min-width 20px, height 20px, radius 10px, bg `#080707`, count in
    800 / 11px / `#FFF`.

---

### 1. Empty / greeting (`view: 'start'`, empty transcript)
**Purpose:** give the shopper a way in without typing.
- Eyebrow `TRY ASKING` — 700 / 11px / `letter-spacing .07em` / uppercase / `#9AA39D`,
  `margin-bottom: 11px`.
- Prompt chips — wrapping flex, `gap: 10px`. Each: bg `#FFF`, radius 24px,
  `padding: 11px 18px`, label 700 / 15px / `#16241D`, shadow `0 4px 12px -6px rgba(8,7,7,.18)`,
  `white-space: nowrap`. Hover: shadow → `0 6px 16px -6px rgba(8,7,7,.26)`. Press `scale(.97)`.
  Six chips from `starterPrompts` — each carries a hard-coded `intent`, so tapping one skips
  intent routing.
- Eyebrow `PICK UP WHERE YOU LEFT OFF`, `margin-top: 26px`.
- Recent rows (today's chats only, max 2) — bg `#FFF`, radius 16px, `padding: 13px 15px`,
  shadow `0 6px 18px -14px rgba(8,7,7,.35)`, gap 11px: 32px `#183A37` avatar circle with the
  logo mark at 21px; title 700 / 14px / `#16241D` (ellipsis); preview 400 / 12px / `#879EA4`
  (ellipsis); trailing time 400 / 11.5px / `#879EA4`.

### 2. Typeahead sheet (composer focused + non-empty draft)
**Purpose:** convert a partial query into a known search term.
- Sheet: `position: absolute; left/right/bottom: 0; top: 150px`, bg `#FFF`, radius
  `28px 28px 42px 42px`, shadow `0 -12px 34px -14px rgba(8,7,7,.28)`, z-index 15. Slides up
  from `translateY(100%)` in 220ms.
- Grab handle: 44×5, radius 3px, `#E4E0D8`, centred, `padding: 12px 0 6px`.
- Rows: `padding: 18px 24px`, `border-bottom: 1px solid #F2EFE9`, hover/press bg `#FAF8F4`.
  Prefix `Looking for… ` 400 / 18px / `#8B968F` + the term 700 / 18px / `#16241D`.
- Matches are substring filtered from `querySuggestions`, capped at 6. Sheet hides when the
  draft empties, on blur, on send, or when voice opens.

### 3. Thinking (`view: 'thinking'`)
- User bubble: right-aligned, max-width 82%, bg `#FFF`, radius `22px 22px 4px 22px`,
  `padding: 13px 18px`, 500 / 16px / line-height 1.4 / `#16241D`, shadow
  `0 4px 12px -6px rgba(8,7,7,.18)`, `margin-bottom: 18px`.
- Thinking bubble: 26px `#183A37` avatar + bubble radius `22px 22px 22px 4px`,
  `padding: 14px 18px`, containing three 7px `#16241D` dots animating
  `translateY(0 → -4px)` with opacity `.35 → 1`, 1.1s loop, staggered 0/150/300ms.
- Trailing label `Checking 4 shops near you` — 500 / 13px / `#8B968F`. Make this string
  reflect what the backend is actually doing.
- Duration: `LATENCY_MS` (1100ms) in the mock. This is the **only** loading affordance — no
  skeletons, no spinners.

### 4. Answer — recipe payload (`intent: 'recipe'`)
- Assistant text row: 26px avatar + body 500 / 16px / line-height 1.45 / `#16241D`, gap 10px,
  `margin-bottom: 16px`.
- **Suggested basket card** — bg `#FFF`, radius 18px, `padding: 15px 17px`, shadow
  `0 6px 18px -12px rgba(8,7,7,.28)`.
  - Header row: eyebrow `SUGGESTED BASKET` 700 / 11px / `.06em` / `#9AA39D`; right-aligned
    total 800 / 13px / `#16241D`.
  - Item rows, gap 11px: 42×42 radius-11 image placeholder; label 700 / 13.5px / `#16241D`
    (ellipsis); store 600 / 11.5px / `#8B968F`; price 800 / 13.5px / `#12A150`; add button
    30×30 circle bg `#16241D`, `+` 20px `#FFF`, press `scale(.88)`.
- **Follow-up chips** — wrapping flex gap 9px, bg `#FFF`, radius 22px, `padding: 10px 16px`,
  700 / 13.5px / `#16241D`. `Add all to basket` · `Cheaper alternatives` ·
  `What else do I need?`

### 5. Answer — store results (`intent: 'stores'`)
- Assistant text row (as above), then a horizontal carousel: `overflow-x: auto`, gap 14px,
  `margin: 0 -20px`, `padding: 2px 20px 6px`, `scroll-snap-type: x mandatory`.
- **Store card** — `flex: 0 0 300px`, `scroll-snap-align: center`, radius 20px, bg `#FFF`,
  shadow `0 10px 26px -14px rgba(8,7,7,.35)`, `overflow: hidden`.
  - Photo band: height 150px, placeholder hatch `repeating-linear-gradient(135deg,#E7E2DA 0
    12px,#DED8CF 12px 24px)`. Deal badge at `top/left: 10px` — 800 / 11px / `#080707`, bg
    `#FAD338`, radius 9px, `padding: 5px 10px`.
  - Body `padding: 14px 16px 16px`:
    - 44px accent circle with initials 900 / 14px / `#FFF`; name 800 / 18px / `#16241D`
      (ellipsis); rating line `⭐ 4.8 (1,240)` — 700 / 12px `#16241D` with the count 600 in
      `#8B968F`.
    - Meta line 1: `cuisine · ⏱ eta · 📍 dist`; line 2: `🚲 delivery · 🧺 min`. Both 600 /
      12.5px / `#5A6B62`, 5px then 12px bottom margin.
    - Rail eyebrow `IN STOCK HERE` — 700 / 11px / `.05em` / `#9AA39D`.
    - **Product rail**: `overflow-x: auto`, gap 12px, `margin: 0 -16px`, `padding: 2px 16px 4px`.
      Tile `flex: 0 0 116px`: 90px radius-12 hatch placeholder with a 30×30 `#16241D` `+`
      button at `right/bottom: 6px`; label 700 / 12.5px, 2-line clamp, `min-height: 31px`;
      price 800 / 13px in `#12A150` (or `#F74242` on the deals payload), optional unit 600 /
      11px `#8B968F`.
- **Page dots** — centred, gap 8px, 8×8 circles: active `#16241D`, inactive `#CFC9BF`,
  `padding: 12px 0 4px`. In the prototype only the first is active; wire these to carousel
  scroll position.
- Follow-ups: `Compare delivery fees` · `Only open now` · `Add cheapest to basket`.

### 6. Answer — deals (`intent: 'deals'`)
Same store card, three deltas: rail eyebrow reads `ON PROMOTION`; product prices render in
`#F74242` with the original struck through (400 / 11px / `#879EA4`); tiles carry a discount
badge at `top/left: 6px` — 700 / 9.5px / `#FFF`, bg `#F74242`, radius 6px, `padding: 3px 6px`.
Follow-ups: `Deals ending today` · `Free delivery only`.

### 7. Answer — reorder (`intent: 'orders'`)
- Order cards, column gap 12px: bg `#FFF`, radius 18px, `padding: 15px 16px`, shadow
  `0 6px 18px -12px rgba(8,7,7,.28)`.
  - 44px `#183A37` initials circle; store 700 / 15px / `#080707`; date 400 / 12px / `#879EA4`;
    total 700 / 15px / `#5CB35E`.
  - Item summary 400 / 12.5px / line-height 1.4 / `#879EA4`, `margin-top: 10px`.
  - `Reorder` CTA: full-width, height 40px, radius 30px, bg accent `#5CB35E`, label 700 / 14px
    `#FFF`. Press `scale(.98)`.
- Follow-ups: `Only in-stock items` · `Repeat weekly`.

### 8. Chat history (`view: 'history'`)
Replaces the transcript entirely (greeting hidden).
- Title `Chat history` 700 / 22px / `#080707`; `Clear all` 500 / 13px / `#F74242` on the right.
- Groups (`Today` / `Yesterday` / `Last 7 days`), gap 22px. Group label 700 / 11px / `.06em` /
  uppercase / `#879EA4`.
- Rows: bg `#FFF`, radius 16px, `padding: 14px 16px`, shadow `0 6px 18px -13px rgba(8,7,7,.3)`,
  36px `#183A37` avatar; title 700 / 14.5px / `#080707`; time 400 / 11.5px / `#879EA4`; preview
  400 / 12.5px / line-height 1.35 / `#879EA4`; message count 500 / 11px / `#5CB35E`.
- **Empty state** (after Clear all): centred, `padding: 70px 24px` — 56px `#E7E2DA` circle with
  the logo mark at 30px / 50% opacity, `No conversations yet` 800 / 17px / `#16241D`, body 500 /
  13.5px / `#879EA4`, max-width 240px.

### 9. Voice capture (overlay, z-index 40)
- Scrim `rgba(8,7,7,.45)`; sheet pinned bottom, bg `#FFF`, radius `28px 28px 42px 42px`,
  `padding: 22px 24px 34px`, centred column gap 16px, slides up in 240ms.
- Grab handle; `Listening…` 800 / 19px / `#16241D`; **9 waveform bars** — 5px wide, 44px tall,
  radius 3px, accent fill, `scaleY(.3 → 1)` loop 0.7–1.24s, staggered 70ms.
- Hint 500 / 14.5px / `#879EA4`, max-width 260px: `Say something like "add palm oil to my basket"`.
- `Cancel` pill (bg `#F3EFE9`, 700 / 15px, radius 30px, `padding: 14px 26px`) and a 64px accent
  stop button (`■`, 26px, `#FFF`) with a pulsing ring
  (`box-shadow: 0 0 0 0 → 14px rgba(92,179,94,.45→0)`, 1.8s).
- Prototype behaviour: stop injects `voice.transcript` and runs it as a normal turn. Wire to
  Web Speech API / native STT; show live partial transcript in place of the hint.

### 10. Error (assistant turn kind `error`)
- 26px `#F74242` circle with `!` 800 / 15px / `#FFF`; card bg `#FFF`, radius
  `4px 18px 18px 18px`, `border-left: 3px solid #F74242`, `padding: 15px 17px`.
- Title `Drop AI couldn’t answer` 800 / 15px / `#080707`; body 500 / 13.5px / `#879EA4`; retry
  button — bg `#16241D`, radius 22px, `padding: 9px 18px`, 700 / 13.5px / `#FFF`. Retry re-runs
  the last query.

### 11. Overflow menu (overlay, z-index 30)
Scrim `rgba(8,7,7,.18)` (tap to dismiss). Panel at `top: 56px; right: 16px`, width 240px, bg
`#FFF`, radius 18px, shadow `0 18px 40px -14px rgba(8,7,7,.4)`, fade+rise 180ms. Rows
`padding: 14px 17px`, `border-bottom: 1px solid #F4F2EE`, hover bg `#FAF8F4`, 20px icon column,
label 700 / 14px. Items: `🕒 Chat history`, `✎ New chat`, `🗑 Clear conversation` (label `#F74242`).

### 12. Toast (z-index 25)
Centred at `bottom: 154px` (just above the composer): bg `#16241D`, radius 30px,
`padding: 12px 20px`, shadow `0 12px 28px -12px rgba(8,7,7,.6)`, 20px accent check circle +
label 700 / 14px / `#FFF`. Auto-dismisses after **1800ms**. Fires on add-to-basket, add-all,
reorder, clear conversation, clear history.

---

## Interactions & behaviour

| Trigger | Result |
|---|---|
| Tap search-bar AI button (home) | Opens Drop AI full-screen at the greeting |
| Type in composer | Typeahead sheet opens (filtered, ≤6 rows); send button turns accent |
| Enter / tap `↑` | Appends user bubble + thinking bubble, clears draft, closes sheet |
| After `LATENCY_MS` | Thinking bubble is replaced by one assistant payload chosen by `routeIntent()` |
| Tap prompt chip | Same as send, but uses the chip's hard-coded `intent` |
| Tap typeahead row | Sends that term |
| Tap recent-chat row / history row | Re-asks that chat's title (real app: rehydrate the thread) |
| Tap product `+` / basket `+` | Basket count +1 immediately, toast `{label} added` |
| `Add all to basket` | Basket count += basket length, toast `3 items added to basket` |
| Other follow-up chip | Sent as a new user turn |
| `Reorder` | Toast `Reordering from {store}` (real app: build the cart and route to checkout) |
| `⋮` → `Chat history` | Transcript swaps for the history list |
| `⋮` → `New chat` / `Clear conversation` | Transcript resets to the greeting |
| `Clear all` in history | History empty state, toast `History cleared` |
| Voice pill | Voice sheet; `Cancel` dismisses; `■` submits the transcript as a turn |
| Back `‹` | Resets to the greeting (in the real app: close Drop AI if already at the greeting) |

**Motion** (mirrors the UrbanDrop/house feel — fast, no bounce):
- Easing `cubic-bezier(.22,.61,.36,1)` everywhere.
- Message enter: fade + 10px rise, 280ms.
- Sheets (typeahead, voice): slide from `translateY(100%)`, 220–240ms.
- Menu: fade + rise, 180ms.
- Toast: fade + rise, 200ms; auto-out at 1800ms.
- Presses: `scale(.85–.98)` depending on element size (values noted per component above).
- Thinking dots 1.1s loop; voice bars 0.7–1.24s loop; stop-button pulse 1.8s.
- New messages should scroll the transcript to the bottom (the prototype relies on natural
  flow). Do **not** use `scrollIntoView` in the prototype — in the app, use your list's
  `scrollToEnd`.

**Responsive:** below 480px, full-screen takeover as specced. At ≥1024px the intended treatment
is a right-hand drawer of the same width (390px) over the page, same internals.

**Accessibility:** all icon buttons need labels (`Back`, `More`, `Send`, `Add to basket`,
`Voice chat`, `Basket`). Hit targets are ≥44px except the 30px product `+` — pad its touch area
out to 44px in the real build. Transcript should be a live region so new assistant turns are
announced. Respect `prefers-reduced-motion`: drop the dot/bar/pulse animations, keep opacity
changes.

## State management

```
view          'start' | 'thinking' | 'answer' | 'history'
messages      Array<{ kind: 'user' | 'thinking' | 'recipe' | 'stores' | 'deals' | 'orders' | 'error', text? }>
draft         string        // composer value
focused       boolean       // composer focus -> drives typeahead with draft
menuOpen      boolean
voiceOpen     boolean
toast         string        // '' = hidden
basketCount   number        // seeded from user.basketCount
historyCleared boolean
lastQuery     string        // for error retry
```

Transitions: `ask(text, intent?)` → push `user` + `thinking`, `view='thinking'` → after
`LATENCY_MS`, pop `thinking`, push the payload kind, `view='answer'`.

**Data fetching when the backend exists.** Replace the `setTimeout` in `ask()` with one call:
`POST /ai/messages { conversationId, text }` returning
`{ replyText, payload: { type: 'recipe'|'stores'|'deals'|'orders', ... } }`. Intent
classification should move server-side — `routeIntent()` in the mock is a regex stand-in.
Basket writes (`POST /basket/items`) stay optimistic with rollback on failure. History is
`GET /ai/conversations?group=recency`. Stream `replyText` token-by-token if the model supports
it; the thinking bubble then becomes the first partial text.

## Design tokens

Source of truth: `prototype/_ds/urbandrop/colors_and_type.css` (from `UrbanDrop.fig`).

**Colour**
| Token | Hex | Use here |
|---|---|---|
| `--ud-green-primary` | `#5CB35E` | Accent — send, CTAs, basket FAB, waveform, store initials |
| `--ud-green-dark` | `#183A37` | AI avatar circles, order initials |
| `--ud-near-black` | `#080707` | Titles in history/orders, toast bg, basket badge |
| ink (panel) | `#16241D` | Primary body & bubble text, add buttons |
| `--ud-muted-teal` | `#879EA4` | Secondary text in history/orders/error |
| muted (panel) | `#8B968F` | Timestamps, store meta secondary, placeholder |
| meta | `#5A6B62` | Store meta lines |
| eyebrow | `#9AA39D` | Section eyebrows |
| price | `#12A150` | In-stock prices |
| `--ud-error-red` | `#F74242` | Sale price, discount badge, destructive, error |
| `--ud-yellow-accent` | `#FAD338` | Store deal badge |
| panel bg | `#F3EFE9` | Drop AI surface |
| surface | `#FFFFFF` | Bubbles, cards, chips, sheets |
| disabled | `#CFC9BF` | Send button (empty draft), inactive dots |
| hatch | `#E7E2DA` / `#DED8CF` / `#F2EFE9` / `#E9E4DC` | Image placeholders |
| hairline | `#F2EFE9` / `#F4F2EE` | Sheet & menu row dividers |
| press bg | `#FAF8F4` | Row press/hover |

**Type** — `Red Hat Display` (all in-panel text; weights 400/500/600/700/800/900).
`Plus Jakarta Sans` is used for the status bar and the prototype's surrounding board only.
Sizes in play: 21 greeting · 19 voice title · 18 typeahead / store name · 16 body & composer ·
15 chips / CTA · 14.5 history title · 13.5 basket label & follow-ups · 12.5 meta · 12 timestamps ·
11 eyebrows (`.05–.07em`, uppercase) · 10 beta pill · 9.5 discount badge.

**Spacing** — page gutter 20px; card padding 14–17px; card gap 10–14px; section gap 22–26px;
carousel gap 14px; product rail gap 12px; chip gap 9–10px.

**Radii** — 42 phone screen · 30 pills/CTAs · 28 composer & sheet top · 24 prompt chips ·
22 bubbles & follow-ups (with a 4px tail corner) · 20 store card · 18 cards/menu · 16 rows ·
12 product image · 11 basket thumb · 9 deal badge · 6 small badges · 50% avatars.

**Shadows** — chips/bubbles `0 4px 12px -6px rgba(8,7,7,.18)` · pills `0 4px 12px -6px rgba(8,7,7,.2)` ·
cards `0 6px 18px -12px rgba(8,7,7,.28)` · rows `0 6px 18px -13px rgba(8,7,7,.3)` ·
store cards `0 10px 26px -14px rgba(8,7,7,.35)` · toast `0 12px 28px -12px rgba(8,7,7,.6)` ·
menu `0 18px 40px -14px rgba(8,7,7,.4)` · typeahead sheet `0 -12px 34px -14px rgba(8,7,7,.28)`.

## Assets
All in `prototype/assets/`, sourced from the original UrbanDrop Figma export:

| File | Where used |
|---|---|
| `logo-mark.png` | AI avatar (header 19px, message 21px, history 24px, empty state 30px) — always on a `#183A37` circle |
| `icon-cart.png`, `icon-bell.png`, `icon-bookmark.png`, `icon-location.png`, `icon-pin.png` | Not used by Drop AI; included so the surrounding app screens are covered |

Emoji glyphs (🎙 🧺 ⭐ ⏱ 📍 🚲 🕒 ✎ 🗑) stand in for icons in the prototype — **replace with the
app's real icon set**. Product and shop photography is placeholder hatch; supply real imagery
at 4:3 for shop banners (300×150) and 1:1 for product tiles (116×90 displayed).

## Files

| Path | What |
|---|---|
| `prototype/Drop AI Chat.dc.html` | The Drop AI prototype — open in a browser. Left rail jumps to any of the 10 states; the phone is fully interactive |
| `prototype/drop-ai-mock.js` | **Mock fixtures + `routeIntent()`** — copy into your project |
| `prototype/_ds/urbandrop/colors_and_type.css` | UrbanDrop design tokens (colour, type, radii, spacing, shadows) |
| `prototype/assets/*` | Image assets |
| `screenshots/*.png` | The 12 state captures above, 546 × 1080 each |
| `prototype/support.js` | Runtime for the prototype file only — not part of the design |
| `reference/Urbandrop Homepage.dc.html` | The full homepage/search board this assistant launches from — use for surrounding context and the original entry point |
| `reference/ProductCard.dc.html` | Existing product tile component for reference |

To view: open `prototype/Drop AI Chat.dc.html` directly in a browser (it loads
`drop-ai-mock.js` as a module, so serve the folder over `http://` — e.g. `npx serve .` — rather
than `file://`).
